# MIMUN 6.0 Conference Countdown

A responsive, static countdown for MIMUN 6.0, beginning **21 November 2026 at 10:00 AM IST** (Asia/Kolkata). It counts down to the opening moment, then changes to a conference-underway state.

## Deploy to Vercel

1. Create a GitHub repository and upload the contents of this folder.
2. In Vercel, choose **Add New → Project**, import the repository, and keep the default settings.
3. Click **Deploy**. No build command or environment variables are required.

Alternatively, install the Vercel CLI with `npm i -g vercel`, authenticate with `vercel login`, run `vercel link` in this directory, verify the linked project with `vercel project inspect --non-interactive`, then run `vercel deploy` for a preview or `vercel deploy --prod` for production.

The local display settings are browser-local only; they do not change the official date for other visitors. Change the default timestamp in `index.html` and redeploy to change the public countdown.
